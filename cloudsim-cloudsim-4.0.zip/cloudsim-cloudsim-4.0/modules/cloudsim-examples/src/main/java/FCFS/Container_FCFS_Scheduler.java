package FCFS;


import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.container.core.ContainerHost;
import org.cloudbus.cloudsim.container.resourceAllocatorMigrationEnabled.PowerContainerVmAllocationPolicyMigrationAbstractHostSelection;
import org.cloudbus.cloudsim.container.resourceAllocators.ContainerVmAllocationPolicy;
import org.cloudbus.cloudsim.container.vmSelectionPolicies.PowerContainerVmSelectionPolicy;
import org.cloudbus.cloudsim.container.vmSelectionPolicies.PowerContainerVmSelectionPolicyMaximumUsage;
import org.cloudbus.cloudsim.container.hostSelectionPolicies.HostSelectionPolicy;
import org.cloudbus.cloudsim.container.hostSelectionPolicies.HostSelectionPolicyFirstFit;
import org.cloudbus.cloudsim.core.CloudSim;
//import org.cloudbus.cloudsim.examples.container.ConstantsExamples;


import utils.Constants;
import utils.DatacenterCreator;
import utils.GenerateMatrices;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

public class Container_FCFS_Scheduler {

	private static List<Cloudlet> cloudletList;
    private static List<Vm> vmList;
    private static Datacenter[] datacenter;
    private static double[][] commMatrix;
    private static double[][] execMatrix;
    private static List<ContainerHost> hostList;
	private static Object containerList;

    private static List<Vm> createVM(int userId, int vms) {
        //Creates a container to store VMs. This list is passed to the broker later
        LinkedList<Vm> list = new LinkedList<Vm>();

        //VM Parameters
        long size = 10000; //image size (MB)
        int ram = 512; //vm memory (MB)
        int mips = 250;
        long bw = 1000;
        int pesNumber = 4; //number of cpus
        String vmm = "Xen"; //VMM name

        //create VMs
        Vm[] vm = new Vm[vms];

        for (int i = 0; i < vms; i++) {
            vm[i] = new Vm(datacenter[i].getId(), userId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerSpaceShared());
            list.add(vm[i]);
        }

        return list;
    }
	private static ArrayList<Integer> getSeedValue(int cloudletcount)
	{
		
		ArrayList<Integer> seed = new ArrayList<Integer>();
		
		Log.printLine(System.getProperty("user.dir") + "/microcloudlets6.txt");
		try {
			File fobj = new File(System.getProperty("user.dir") + "/microcloudlets6.txt");
			java.util.Scanner readFile = new java.util.Scanner(fobj);
			while (readFile.hasNextLine() && cloudletcount>0)
			{
				seed.add(readFile.nextInt());
				cloudletcount --;
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace(); 
		}		
		return seed;
	}
    private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift) {
        // Creates a container to store Cloudlets
    	ArrayList<Integer> randomSeed = getSeedValue(cloudlets);
        LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

        //cloudlet parameters
        long fileSize = 300;
        long outputSize = 300;
        int pesNumber = 1;
        UtilizationModel utilizationModel = new UtilizationModelFull();

        Cloudlet[] cloudlet = new Cloudlet[cloudlets];

        for (int i = 0; i < cloudlets; i++) {
        	long finalLen =  randomSeed.get(i);
            int dcId = (int) (Math.random() * Constants.NO_OF_DATA_CENTERS);
            long length = (long) (1e3 * (commMatrix[i][dcId] + execMatrix[i][dcId]));
            cloudlet[i] = new Cloudlet(idShift + i, finalLen, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
            // setting the owner of these Cloudlets
            cloudlet[i].setUserId(userId);
            cloudlet[i].setVmId(dcId + 2);
            list.add(cloudlet[i]);
        }
        return list;
    }

    public static void main(String[] args) {
        Log.printLine("Starting FCFS Scheduler...");

        new GenerateMatrices();
        execMatrix = GenerateMatrices.getExecMatrix();
        commMatrix = GenerateMatrices.getCommMatrix();

        try {
            int num_user = 1;   // number of grid users
            Calendar calendar = Calendar.getInstance();
            boolean trace_flag = false;  // mean trace events

            CloudSim.init(num_user, calendar, trace_flag);

            // Second step: Create Datacenters
            datacenter = new Datacenter[Constants.NO_OF_DATA_CENTERS];
            for (int i = 0; i < Constants.NO_OF_DATA_CENTERS; i++) {
                datacenter[i] = DatacenterCreator.createDatacenter("Datacenter_" + i);
            }

            //Third step: Create Broker
            ContainerFCFSDatacenterBroker broker = createBroker("Broker_0");
            
            int brokerId = broker.getId();

            //Fourth step: Create VMs,Containers and Cloudlets and send them to broker
            
            vmList = createVM(brokerId, Constants.NO_OF_DATA_CENTERS);
            containerList = createContainerList(brokerId, Constants.NUMBER_CLOUDLETS);
            cloudletList = createCloudlet(brokerId, Constants.NO_OF_TASKS, 0);
            
            double overUtilizationThreshold = 0.80;
            double underUtilizationThreshold = 0.70;
			hostList = new ArrayList<ContainerHost>();
	        hostList = createHostList(Constants.NUMBER_HOSTS);
	        PowerContainerVmSelectionPolicy vmSelectionPolicy = new PowerContainerVmSelectionPolicyMaximumUsage();
	        HostSelectionPolicy hostSelectionPolicy = new HostSelectionPolicyFirstFit();
			
			ContainerVmAllocationPolicy ContainervmAllocationPolicy = new
					PowerContainerVmAllocationPolicyMigrationAbstractHostSelection(hostList, vmSelectionPolicy,
                    hostSelectionPolicy, overUtilizationThreshold, underUtilizationThreshold);
			//Log.printLine(ContainervmAllocationPolicy);
			
			broker.submitContainerList(ContainervmAllocationPolicy);
            broker.submitVmList(vmList);
            broker.submitCloudletList(cloudletList);

            // Fifth step: Starts the simulation
            CloudSim.startSimulation();

            // Final step: Print results when simulation is over
            List<Cloudlet> newList = broker.getCloudletReceivedList();
            //newList.addAll(globalBroker.getBroker().getCloudletReceivedList());

            CloudSim.stopSimulation();

            printCloudletList(newList);

            Log.printLine(Container_FCFS_Scheduler.class.getName() + " finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("The simulation has been terminated due to an unexpected error");
        }
    }

    private static Object createContainerList(int brokerId, int numberCloudlets) {
		// TODO Auto-generated method stub
		return null;
	}
	private static List<ContainerHost> createHostList(int numberHosts) {
		// TODO Auto-generated method stub
		return null;
	}
	private static ContainerFCFSDatacenterBroker createBroker(String name) throws Exception {
        return new ContainerFCFSDatacenterBroker(name);
    }

    /**
     * Prints the Cloudlet objects
     *
     * @param list list of Cloudlets
     */
    private static void printCloudletList(List<Cloudlet> list) {
        int size = list.size();
        Cloudlet cloudlet;

        String indent = "    ";
        Log.printLine();
        Log.printLine("========== OUTPUT ==========");
		Log.printLine("CloudletID" + indent +
				"DataCenterID" + indent +
				"CloudletLength" + indent +
				"VMID" + indent + indent +
				"ContainerID" + indent +
				"CPU Utilization" + indent +
				"Time" + indent +
				"StartTime" + indent +
				"FinishTime");

        DecimalFormat dft = new DecimalFormat("###.##");
        dft.setMinimumIntegerDigits(2);
        for (int i = 0; i < size; i++) {
            cloudlet = list.get(i);
            Log.print(indent + dft.format(cloudlet.getCloudletId()) + indent + indent);

            if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
            	Log.printLine(indent + cloudlet.getResourceId() 
            			+ indent + indent + indent + indent + cloudlet.getCloudletLength()
            			+ indent + indent + indent + cloudlet.getVmId() 
        				+ indent + indent + indent + cloudlet.getConId()
             			+ indent + indent + indent + dft.format(cloudlet.getUtilizationOfCpu(cloudlet.getActualCPUTime()))
        				+ indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) 
        				+ indent + dft.format(cloudlet.getExecStartTime())
        			    + indent + indent + dft.format(cloudlet.getFinishTime()));
        		}
        }
        double makespan = calcMakespan(list);
        Log.printLine("Makespan using FCFS: " + makespan);
    }

    private static double calcMakespan(List<Cloudlet> list) {
        double makespan = 0;
        double[] dcWorkingTime = new double[Constants.NO_OF_DATA_CENTERS];

        for (int i = 0; i < Constants.NO_OF_TASKS; i++) {
            int dcId = list.get(i).getVmId() % Constants.NO_OF_DATA_CENTERS;
            if (dcWorkingTime[dcId] != 0) --dcWorkingTime[dcId];
            dcWorkingTime[dcId] += execMatrix[i][dcId] + commMatrix[i][dcId];
            makespan = Math.max(makespan, dcWorkingTime[dcId]);
        }
        return makespan;
    }
}