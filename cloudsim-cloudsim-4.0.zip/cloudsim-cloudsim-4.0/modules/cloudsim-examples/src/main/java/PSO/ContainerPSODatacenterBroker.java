package PSO;


import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.DatacenterBrokerv2;
import org.cloudbus.cloudsim.container.resourceAllocators.ContainerVmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.lists.VmList;


import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ContainerPSODatacenterBroker extends DatacenterBrokerv2 {

    private double[] mapping;

    ContainerPSODatacenterBroker(String name) throws Exception {
        super(name);
    }

    public void setMapping(double[] mapping) {
        this.mapping = mapping;
    }

    private List<Cloudlet> assignCloudletsToVms(List<Cloudlet> cloudlist) {
        int idx = 0;
        for (Cloudlet cl : cloudlist) {
            cl.setVmId((int) mapping[idx++]);
            cl.setconId(100);
        }
        return cloudlist;
    }

    @Override
    protected void submitCloudlets() {
    	for (int i = 0; i < 20; i++) {
    		String a = "count";
    		String b = String.valueOf(i);
    		String ab = a+b;
    		Log.printLine(ab);
    		final AtomicInteger count0  = new AtomicInteger(0);
    		  //System.out.println(i);
    	}
		final AtomicInteger count0  = new AtomicInteger(0);
		final AtomicInteger count1  = new AtomicInteger(0);
		final AtomicInteger count2  = new AtomicInteger(0);
		final AtomicInteger count3  = new AtomicInteger(0);
		final AtomicInteger count4  = new AtomicInteger(0);
		final AtomicInteger count5  = new AtomicInteger(0);
		final AtomicInteger count6  = new AtomicInteger(0);
		final AtomicInteger count7  = new AtomicInteger(0);
		final AtomicInteger count8  = new AtomicInteger(0);
		final AtomicInteger count9  = new AtomicInteger(0);
		final AtomicInteger count10  = new AtomicInteger(0);
		final AtomicInteger count11  = new AtomicInteger(0);
        List<Cloudlet> tasks = assignCloudletsToVms(getCloudletList());
        int vmIndex = 0;
        for (Cloudlet cloudlet : tasks) {
            Vm vm;
            // if user didn't bind this cloudlet and it has not been executed yet
            if (cloudlet.getVmId() == -1) {
                vm = getVmsCreatedList().get(vmIndex);
            } else { // submit to the specific vm
                vm = VmList.getById(getVmsCreatedList(), cloudlet.getVmId());
                if (vm == null) { // vm was not created
                    Log.printLine(CloudSim.clock() + ": " + getName() + ": Postponing execution of cloudlet "
                            + cloudlet.getCloudletId() + ": bount VM not available");
                    continue;
                }
            }

            Log.printLine(CloudSim.clock() + ": " + getName() + ": Sending cloudlet "
                    + cloudlet.getCloudletId() + " to VM #" + vm.getId());
            cloudlet.setVmId(vm.getId());

				
            if(cloudlet.getVmId() == 0) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count0.incrementAndGet()));
				if(k>3) {
					count0.getAndSet(1);
				}
				cloudlet.setconId(k);
									
			}else if(cloudlet.getVmId() == 1) {
				//int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count1.incrementAndGet()));
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count1.incrementAndGet()));
				if(count1.get() > vm.getNumberOfPes()-1) {
					count1.getAndSet(0);
				}
				cloudlet.setconId(k);	
			}else if(cloudlet.getVmId() == 2) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count2.incrementAndGet()));
				if(count2.get() > vm.getNumberOfPes()-1) {
					count2.getAndSet(0);
				}
				cloudlet.setconId(k);
			
			}else if(cloudlet.getVmId() == 3) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count3.incrementAndGet()));
				if(count3.get() > vm.getNumberOfPes()-1) {
					count3.getAndSet(0);
				}
				cloudlet.setconId(k);
			}else if(cloudlet.getVmId() == 4) {
				//int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count1.incrementAndGet()));
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count4.incrementAndGet()));
				if(count4.get() > vm.getNumberOfPes()-1) {
					count4.getAndSet(0);
				}
				cloudlet.setconId(k);	
			}else if(cloudlet.getVmId() == 5) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count5.incrementAndGet()));
				if(count5.get() > vm.getNumberOfPes()-1) {
					count5.getAndSet(0);
				}
				cloudlet.setconId(k);
			
			}else if(cloudlet.getVmId() == 6) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count6.incrementAndGet()));
				if(count6.get() > vm.getNumberOfPes()-1) {
					count6.getAndSet(0);
				}
				cloudlet.setconId(k);
			}else if(cloudlet.getVmId() == 7) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count7.incrementAndGet()));
				if(count7.get() > vm.getNumberOfPes()-1) {
					count7.getAndSet(0);
				}
				cloudlet.setconId(k);
			
			}else if(cloudlet.getVmId() == 8) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count8.incrementAndGet()));
				if(count8.get() > vm.getNumberOfPes()-1) {
					count8.getAndSet(0);
				}
				cloudlet.setconId(k);
			}else if(cloudlet.getVmId() == 9) {
				//int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count1.incrementAndGet()));
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count9.incrementAndGet()));
				if(count9.get() > vm.getNumberOfPes()-1) {
					count9.getAndSet(0);
				}
				cloudlet.setconId(k);	
			}else if(cloudlet.getVmId() == 10) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count10.incrementAndGet()));
				if(count10.get() > vm.getNumberOfPes()-1) {
					count10.getAndSet(0);
				}
				cloudlet.setconId(k);
			
			}else if(cloudlet.getVmId() == 11) {
				int k = Integer.valueOf(String.valueOf(cloudlet.getVmId()) + String.valueOf(count11.incrementAndGet()));
				if(count11.get() > vm.getNumberOfPes()-1) {
					count11.getAndSet(0);
				}
				cloudlet.setconId(k);
			}
            //cloudlet.setconId(vm.getId());
            sendNow(getVmsToDatacentersMap().get(vm.getId()), CloudSimTags.CLOUDLET_SUBMIT, cloudlet);
            cloudletsSubmitted++;
            vmIndex = (vmIndex + 1) % getVmsCreatedList().size();
            getCloudletSubmittedList().add(cloudlet);
        }
    }

    @Override
    protected void processResourceCharacteristics(SimEvent ev) {
        DatacenterCharacteristics characteristics = (DatacenterCharacteristics) ev.getData();
        getDatacenterCharacteristicsList().put(characteristics.getId(), characteristics);

        if (getDatacenterCharacteristicsList().size() == getDatacenterIdsList().size()) {
            distributeRequestsForNewVmsAcrossDatacenters();
        }
    }

    protected void distributeRequestsForNewVmsAcrossDatacenters() {
        int numberOfVmsAllocated = 0;
        int i = 0;

        final List<Integer> availableDatacenters = getDatacenterIdsList();

        for (Vm vm : getVmList()) {
            int datacenterId = availableDatacenters.get(i++ % availableDatacenters.size());
            String datacenterName = CloudSim.getEntityName(datacenterId);

            if (!getVmsToDatacentersMap().containsKey(vm.getId())) {
                Log.printLine(CloudSim.clock() + ": " + getName() + ": Trying to Create VM #" + vm.getId() + " in " + datacenterName);
                sendNow(datacenterId, CloudSimTags.VM_CREATE_ACK, vm);
                numberOfVmsAllocated++;
            }
        }

        setVmsRequested(numberOfVmsAllocated);
        setVmsAcks(0);
    }
    
	public void submitContainerList(ContainerVmAllocationPolicy vmAllocationPolicy) {
		Log.printLine(CloudSim.clock() + " All Cloudlets executed. Finishing...");
		
	}

}
